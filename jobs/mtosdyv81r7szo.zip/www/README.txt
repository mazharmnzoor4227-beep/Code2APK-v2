Code2APK Android App frontend

Use this ZIP inside your working Code2APK-v2 website:
1. Upload this ZIP.
2. App name: Code2APK
3. Package ID: com.code2apk.builder
4. Upload your app icon.
5. Preview if you want.
6. Generate APK.
7. Install the APK.

In the installed app:
- The GitHub owner/repository fields are hidden and fixed.
- The token section is NOT shown on the main screen.
- Tap the gear icon once and paste your existing fine-grained token.
- After saving, normal use is only: Paste Code / Upload ZIP → App name → Icon → Generate APK.

Important: the token is NOT hardcoded into the APK, because embedding it inside the APK would make it extractable.
