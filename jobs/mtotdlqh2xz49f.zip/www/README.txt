Mera Urdu Assistant - English UI version

The app interface is in English.
The assistant can still understand Urdu/Hindi voice commands and speak replies in Urdu.

Suggested App Name: Mera Urdu Assistant
Package ID: com.urdu.assistant
